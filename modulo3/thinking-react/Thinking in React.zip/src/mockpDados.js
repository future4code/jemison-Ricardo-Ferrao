export const tarefas=[
    {id:"",texto:"Tarefa1",status:false},
    {id:"",texto:"Tarefa2",status:false},
    {id:"",texto:"Tarefa3",status:false},
    {id:"",texto:"Tarefa4",status:false},
]