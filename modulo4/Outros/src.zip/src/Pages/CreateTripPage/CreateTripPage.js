import React from 'react';


function CreateTripPage () {
    return(
        <div>
            <h1> Formulário para o administrador criar uma nova viagem</h1>
            <button>criar</button>

        </div>
    )
}

export default CreateTripPage;